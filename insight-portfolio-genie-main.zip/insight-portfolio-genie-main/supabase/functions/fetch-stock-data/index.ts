
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { symbols } = await req.json();
    
    if (!symbols || !Array.isArray(symbols)) {
      return new Response(
        JSON.stringify({ error: 'symbols array is required' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    const apiKey = Deno.env.get('ALPHA_VANTAGE_API_KEY');
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: 'API key not configured' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    console.log('Fetching stock data for symbols:', symbols);

    // Fetch stock data for each symbol
    const stockDataPromises = symbols.map(async (symbol: string) => {
      try {
        // Remove .NS suffix for Alpha Vantage API call
        const cleanSymbol = symbol.replace('.NS', '');
        
        // Use Alpha Vantage GLOBAL_QUOTE function for real-time data
        const url = `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${cleanSymbol}&apikey=${apiKey}`;
        
        console.log(`Fetching data for ${cleanSymbol} from Alpha Vantage`);
        
        const response = await fetch(url);
        const data = await response.json();
        
        console.log(`Response for ${cleanSymbol}:`, data);

        if (data['Global Quote'] && data['Global Quote']['05. price']) {
          const quote = data['Global Quote'];
          return {
            symbol: symbol,
            price: parseFloat(quote['05. price']),
            change: parseFloat(quote['09. change']),
            changePercent: parseFloat(quote['10. change percent'].replace('%', '')),
            success: true
          };
        } else {
          console.log(`No valid data found for ${cleanSymbol}`);
          return {
            symbol: symbol,
            error: 'No data available',
            success: false
          };
        }
      } catch (error) {
        console.error(`Error fetching data for ${symbol}:`, error);
        return {
          symbol: symbol,
          error: error.message,
          success: false
        };
      }
    });

    const results = await Promise.all(stockDataPromises);
    
    console.log('Final results:', results);

    return new Response(
      JSON.stringify({ stockData: results }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );

  } catch (error) {
    console.error('Error in fetch-stock-data function:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
