
export interface QuestionOption {
  value: number;
  text: string;
}

export interface RiskQuestion {
  id: number;
  question: string;
  options: QuestionOption[];
}

export interface UserResponse {
  questionId: number;
  value: number;
}

export type RiskProfile = "Conservative" | "Moderately Conservative" | "Moderate" | "Moderately Aggressive" | "Aggressive";

export interface AssetAllocation {
  name: string;
  percentage: number;
  color: string;
}

export interface PortfolioRecommendation {
  title: string;
  description: string;
  expectedReturn: string;
  riskLevel: RiskProfile;
  volatility: string;
  allocation: AssetAllocation[];
  historicalPerformance?: HistoricalPerformance[];
}

export interface HistoricalPerformance {
  year: string;
  return: number;
}

export interface ReportData {
  name: string;
  email?: string;
  investmentGoals?: string;
  riskProfile: RiskProfile;
  portfolio: PortfolioRecommendation;
  date: string;
  aiInsights: string;
}

export interface UserProfile {
  name: string;
  email: string;
  investmentGoals: string;
}

// New types for Indian Stock Market Analysis
export interface StockData {
  symbol: string;
  name: string;
  sector: string;
  currentPrice: number;
  historicalReturns: {
    oneYear: number;
    threeYear: number;
    fiveYear: number;
    tenYear: number;
  };
  riskLevel: RiskProfile;
  volatility: string;
  description: string;
}

export interface InvestmentPreference {
  amount: number;
  expectedReturn: number;
  investmentHorizon: number;
}

export interface InvestmentSimulation {
  year: number;
  investmentValue: number;
  annualReturn: number;
  cumulativeReturn: number;
}

export interface RecommendedStock {
  stock: StockData;
  allocationPercentage: number;
  allocationAmount: number;
}
