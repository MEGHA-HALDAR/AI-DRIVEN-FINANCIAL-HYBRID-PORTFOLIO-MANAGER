
import { useState } from "react";
import InvestmentForm from "@/components/IndianStockMarket/InvestmentForm";
import StockRecommendations from "@/components/IndianStockMarket/StockRecommendations";
import SimulationResults from "@/components/IndianStockMarket/SimulationResults";
import { InvestmentPreference, RecommendedStock, InvestmentSimulation } from "@/types";
import { getRecommendedStocks, runInvestmentSimulation } from "@/utils/stockMarketUtils";

const stages = {
  INVESTMENT_FORM: "investment_form",
  STOCK_RECOMMENDATIONS: "stock_recommendations",
  SIMULATION_RESULTS: "simulation_results"
};

const IndianStockMarket = () => {
  const [stage, setStage] = useState(stages.INVESTMENT_FORM);
  const [investmentPreferences, setInvestmentPreferences] = useState<InvestmentPreference | null>(null);
  const [recommendedStocks, setRecommendedStocks] = useState<RecommendedStock[]>([]);
  const [selectedStocks, setSelectedStocks] = useState<RecommendedStock[]>([]);
  const [simulationData, setSimulationData] = useState<InvestmentSimulation[]>([]);
  
  const handleInvestmentComplete = (preferences: InvestmentPreference) => {
    const recommended = getRecommendedStocks(preferences);
    setInvestmentPreferences(preferences);
    setRecommendedStocks(recommended);
    setStage(stages.STOCK_RECOMMENDATIONS);
  };
  
  const handleStockSelection = (selected: RecommendedStock[]) => {
    setSelectedStocks(selected);
    
    // Run simulation
    if (investmentPreferences) {
      const simulation = runInvestmentSimulation(
        investmentPreferences.amount,
        selected,
        investmentPreferences.investmentHorizon
      );
      setSimulationData(simulation);
      setStage(stages.SIMULATION_RESULTS);
    }
  };
  
  const handleReset = () => {
    setStage(stages.INVESTMENT_FORM);
    setInvestmentPreferences(null);
    setRecommendedStocks([]);
    setSelectedStocks([]);
    setSimulationData([]);
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      <div className="container px-4 py-8 max-w-6xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-finance-blue mb-2">Indian Stock Market Analysis</h1>
          <p className="text-muted-foreground">Analyze and simulate investments in the Indian stock market</p>
        </header>
        
        {stage === stages.INVESTMENT_FORM && (
          <InvestmentForm onComplete={handleInvestmentComplete} />
        )}
        
        {stage === stages.STOCK_RECOMMENDATIONS && investmentPreferences && (
          <StockRecommendations 
            preferences={investmentPreferences}
            recommendedStocks={recommendedStocks}
            onSelectStocks={handleStockSelection}
            onBack={() => setStage(stages.INVESTMENT_FORM)}
          />
        )}
        
        {stage === stages.SIMULATION_RESULTS && investmentPreferences && (
          <SimulationResults 
            preferences={investmentPreferences}
            selectedStocks={selectedStocks}
            simulationData={simulationData}
            onReset={handleReset}
          />
        )}
        
        <footer className="mt-12 text-center text-xs text-muted-foreground">
          <p>© 2025 AI Financial Portfolio Manager | Educational Purposes Only</p>
          <p className="mt-1">This tool is for educational demonstration purposes and does not provide actual financial advice.</p>
        </footer>
      </div>
    </div>
  );
};

export default IndianStockMarket;
