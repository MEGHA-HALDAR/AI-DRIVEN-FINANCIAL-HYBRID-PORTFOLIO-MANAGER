
import { useState } from "react";
import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import UserInfoForm from "@/components/UserInfoForm";
import RiskAssessment from "@/components/RiskAssessment";
import RiskProfile from "@/components/RiskProfile";
import PortfolioRecommendation from "@/components/PortfolioRecommendation";
import ReportGeneration from "@/components/ReportGeneration";
import { ChartLine } from "lucide-react";
import { UserResponse, RiskProfile as RiskProfileType, PortfolioRecommendation as PortfolioRecommendationType, ReportData, UserProfile } from "@/types";
import { calculateRiskScore, mapScoreToProfile, getPortfolioRecommendations } from "@/utils/portfolioUtils";

const stages = {
  LANDING: "landing",
  USER_INFO: "user_info",
  RISK_ASSESSMENT: "risk_assessment",
  RISK_PROFILE: "risk_profile",
  PORTFOLIO_RECOMMENDATION: "portfolio_recommendation",
  REPORT_GENERATION: "report_generation"
};

const Index = () => {
  const [stage, setStage] = useState(stages.LANDING);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [userResponses, setUserResponses] = useState<UserResponse[]>([]);
  const [riskScore, setRiskScore] = useState<number>(0);
  const [riskProfile, setRiskProfile] = useState<RiskProfileType>("Moderate");
  const [portfolios, setPortfolios] = useState<PortfolioRecommendationType[]>([]);
  const [selectedPortfolio, setSelectedPortfolio] = useState<PortfolioRecommendationType | null>(null);

  const handleUserInfoComplete = (profile: UserProfile) => {
    setUserProfile(profile);
    setStage(stages.RISK_ASSESSMENT);
  };

  const handleRiskAssessmentComplete = (responses: UserResponse[]) => {
    setUserResponses(responses);
    
    const score = calculateRiskScore(responses);
    const profile = mapScoreToProfile(score);
    
    setRiskScore(score);
    setRiskProfile(profile);
    
    setStage(stages.RISK_PROFILE);
  };
  
  const handleViewPortfolios = () => {
    const recommendedPortfolios = getPortfolioRecommendations(riskProfile);
    setPortfolios(recommendedPortfolios);
    setStage(stages.PORTFOLIO_RECOMMENDATION);
  };
  
  const handleSelectPortfolio = (portfolio: PortfolioRecommendationType) => {
    setSelectedPortfolio(portfolio);
    setStage(stages.REPORT_GENERATION);
  };
  
  const handleReset = () => {
    setUserProfile(null);
    setUserResponses([]);
    setRiskScore(0);
    setRiskProfile("Moderate");
    setPortfolios([]);
    setSelectedPortfolio(null);
    setStage(stages.LANDING);
  };
  
  const startAssessment = () => {
    setStage(stages.USER_INFO);
  };

  // Generate report data for the AI component
  const getReportData = (): ReportData => {
    return {
      name: userProfile?.name || "Investor",
      email: userProfile?.email,
      investmentGoals: userProfile?.investmentGoals,
      riskProfile: riskProfile,
      portfolio: selectedPortfolio!,
      date: new Date().toLocaleDateString(),
      aiInsights: ""
    };
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      <div className="container px-4 py-8 max-w-6xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-finance-blue mb-2">AI Financial Portfolio Manager</h1>
          <p className="text-muted-foreground">Create an optimized investment portfolio based on your risk profile</p>
        </header>

        {stage === stages.LANDING && (
          <Card className="w-full max-w-4xl mx-auto shadow-lg animate-fade-in portfolio-card">
            <CardContent className="p-8">
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div className="space-y-4">
                  <h2 className="text-2xl font-bold">Your Personal AI Investment Advisor</h2>
                  <p className="text-muted-foreground">
                    Find the perfect investment strategy tailored to your unique financial goals and risk tolerance.
                  </p>
                  
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <div className="bg-finance-teal rounded-full h-6 w-6 flex items-center justify-center text-white text-sm mr-2">1</div>
                      <p>Share your investment goals and preferences</p>
                    </div>
                    <div className="flex items-center">
                      <div className="bg-finance-teal rounded-full h-6 w-6 flex items-center justify-center text-white text-sm mr-2">2</div>
                      <p>Complete a short risk assessment questionnaire</p>
                    </div>
                    <div className="flex items-center">
                      <div className="bg-finance-teal rounded-full h-6 w-6 flex items-center justify-center text-white text-sm mr-2">3</div>
                      <p>Review your personalized risk profile</p>
                    </div>
                    <div className="flex items-center">
                      <div className="bg-finance-teal rounded-full h-6 w-6 flex items-center justify-center text-white text-sm mr-2">4</div>
                      <p>Compare AI-recommended portfolios</p>
                    </div>
                    <div className="flex items-center">
                      <div className="bg-finance-teal rounded-full h-6 w-6 flex items-center justify-center text-white text-sm mr-2">5</div>
                      <p>Get detailed AI insights and a downloadable report</p>
                    </div>
                  </div>
                  
                  <div className="pt-4 space-y-3">
                    <button 
                      onClick={startAssessment} 
                      className="w-full py-3 rounded-md bg-finance-blue text-white font-medium hover:bg-finance-blue/90 transition-colors"
                    >
                      Start Your Assessment
                    </button>
                    
                    <div className="relative">
                      <div className="absolute inset-0 flex items-center">
                        <span className="w-full border-t" />
                      </div>
                      <div className="relative flex justify-center text-xs uppercase">
                        <span className="bg-gradient-to-b from-gray-50 to-gray-100 px-2 text-muted-foreground">or</span>
                      </div>
                    </div>
                    
                    <Button variant="outline" className="w-full" asChild>
                      <Link to="/indian-stock-market" className="flex items-center justify-center">
                        <ChartLine className="mr-2 h-4 w-4" />
                        Analyze Indian Stock Market
                      </Link>
                    </Button>
                  </div>
                </div>
                
                <div className="flex justify-center">
                  <div className="finance-gradient rounded-2xl p-6 text-white">
                    <h3 className="font-bold mb-2">AI-Powered Analysis</h3>
                    <p className="mb-4 opacity-90 text-sm">Our advanced AI system analyzes your risk profile and provides personalized investment recommendations.</p>
                    
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="bg-white/10 rounded-lg p-3">
                        <div className="font-medium">Risk Assessment</div>
                        <div className="opacity-75">Scientific profiling methods</div>
                      </div>
                      <div className="bg-white/10 rounded-lg p-3">
                        <div className="font-medium">Portfolio Optimization</div>
                        <div className="opacity-75">Efficient allocation models</div>
                      </div>
                      <div className="bg-white/10 rounded-lg p-3">
                        <div className="font-medium">Smart Diversification</div>
                        <div className="opacity-75">Balanced asset selection</div>
                      </div>
                      <div className="bg-white/10 rounded-lg p-3">
                        <div className="font-medium">Performance Projections</div>
                        <div className="opacity-75">Research-based forecasts</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {stage === stages.USER_INFO && (
          <UserInfoForm onComplete={handleUserInfoComplete} />
        )}

        {stage === stages.RISK_ASSESSMENT && (
          <RiskAssessment onComplete={handleRiskAssessmentComplete} />
        )}
        
        {stage === stages.RISK_PROFILE && (
          <RiskProfile 
            score={riskScore} 
            profile={riskProfile} 
            onContinue={handleViewPortfolios} 
          />
        )}
        
        {stage === stages.PORTFOLIO_RECOMMENDATION && (
          <PortfolioRecommendation 
            portfolios={portfolios} 
            onSelectPortfolio={handleSelectPortfolio} 
          />
        )}
        
        {stage === stages.REPORT_GENERATION && selectedPortfolio && (
          <ReportGeneration 
            reportData={getReportData()} 
            onReset={handleReset} 
          />
        )}
        
        <footer className="mt-12 text-center text-xs text-muted-foreground">
          <p>© 2025 AI Financial Portfolio Manager | Educational Purposes Only</p>
          <p className="mt-1">This tool is for educational demonstration purposes and does not provide actual financial advice.</p>
        </footer>
      </div>
    </div>
  );
};

export default Index;
