
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export const useRealTimeStockData = (symbols: string[]) => {
  return useQuery({
    queryKey: ['stock-data', symbols],
    queryFn: async () => {
      console.log('Fetching real-time stock data for:', symbols);
      
      const { data, error } = await supabase.functions.invoke('fetch-stock-data', {
        body: { symbols }
      });

      if (error) {
        console.error('Error calling edge function:', error);
        throw new Error(error.message);
      }

      console.log('Received stock data:', data);
      return data.stockData;
    },
    enabled: symbols.length > 0,
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchInterval: 5 * 60 * 1000, // Refetch every 5 minutes
  });
};
