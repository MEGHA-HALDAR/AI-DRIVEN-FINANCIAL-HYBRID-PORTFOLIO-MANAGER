
import { StockData, RiskProfile, InvestmentPreference, InvestmentSimulation, RecommendedStock } from "@/types";

// Sample Indian stock market data
const stocksData: StockData[] = [
  {
    symbol: "RELIANCE.NS",
    name: "Reliance Industries",
    sector: "Energy",
    currentPrice: 2850.75,
    historicalReturns: {
      oneYear: 15.2,
      threeYear: 12.8,
      fiveYear: 18.5,
      tenYear: 16.2
    },
    riskLevel: "Moderate",
    volatility: "Medium",
    description: "India's largest private sector company with interests in petroleum, retail, and telecommunications."
  },
  {
    symbol: "TCS.NS",
    name: "Tata Consultancy Services",
    sector: "IT",
    currentPrice: 3455.20,
    historicalReturns: {
      oneYear: 9.8,
      threeYear: 14.7,
      fiveYear: 16.2,
      tenYear: 18.5
    },
    riskLevel: "Moderately Conservative",
    volatility: "Low to Medium",
    description: "India's largest IT services company providing business solutions to global enterprises."
  },
  {
    symbol: "HDFCBANK.NS",
    name: "HDFC Bank",
    sector: "Banking",
    currentPrice: 1520.35,
    historicalReturns: {
      oneYear: 8.5,
      threeYear: 13.6,
      fiveYear: 15.8,
      tenYear: 17.3
    },
    riskLevel: "Moderately Conservative",
    volatility: "Low to Medium",
    description: "One of India's leading private banks with strong retail presence."
  },
  {
    symbol: "INFY.NS",
    name: "Infosys",
    sector: "IT",
    currentPrice: 1450.90,
    historicalReturns: {
      oneYear: 7.2,
      threeYear: 12.5,
      fiveYear: 15.3,
      tenYear: 16.7
    },
    riskLevel: "Moderate",
    volatility: "Medium",
    description: "A global leader in next-generation digital services and consulting."
  },
  {
    symbol: "HINDUNILVR.NS",
    name: "Hindustan Unilever",
    sector: "FMCG",
    currentPrice: 2580.45,
    historicalReturns: {
      oneYear: 6.5,
      threeYear: 10.2,
      fiveYear: 14.7,
      tenYear: 16.5
    },
    riskLevel: "Conservative",
    volatility: "Low",
    description: "India's largest fast-moving consumer goods company with diverse product portfolio."
  },
  {
    symbol: "BAJFINANCE.NS",
    name: "Bajaj Finance",
    sector: "Financial Services",
    currentPrice: 6980.60,
    historicalReturns: {
      oneYear: 22.5,
      threeYear: 18.6,
      fiveYear: 20.3,
      tenYear: 25.4
    },
    riskLevel: "Aggressive",
    volatility: "High",
    description: "Leading non-banking financial company in India offering various financial services."
  },
  {
    symbol: "ADANIENT.NS",
    name: "Adani Enterprises",
    sector: "Diversified",
    currentPrice: 2350.25,
    historicalReturns: {
      oneYear: 35.8,
      threeYear: 42.7,
      fiveYear: 32.5,
      tenYear: 27.8
    },
    riskLevel: "Aggressive",
    volatility: "Very High",
    description: "The flagship entity of the Adani Group with businesses spanning resources, logistics, and energy sectors."
  },
  {
    symbol: "SBIN.NS",
    name: "State Bank of India",
    sector: "Banking",
    currentPrice: 590.75,
    historicalReturns: {
      oneYear: 14.2,
      threeYear: 11.6,
      fiveYear: 12.8,
      tenYear: 10.5
    },
    riskLevel: "Moderately Aggressive",
    volatility: "Medium to High",
    description: "India's largest public sector bank with extensive domestic and international presence."
  },
  {
    symbol: "TITAN.NS",
    name: "Titan Company",
    sector: "Consumer Durables",
    currentPrice: 2780.30,
    historicalReturns: {
      oneYear: 16.3,
      threeYear: 17.8,
      fiveYear: 20.1,
      tenYear: 22.3
    },
    riskLevel: "Moderate",
    volatility: "Medium",
    description: "Leading manufacturer of watches, jewelry, and eyewear in India."
  },
  {
    symbol: "ICICIBANK.NS",
    name: "ICICI Bank",
    sector: "Banking",
    currentPrice: 950.85,
    historicalReturns: {
      oneYear: 13.5,
      threeYear: 15.7,
      fiveYear: 17.2,
      tenYear: 16.4
    },
    riskLevel: "Moderate",
    volatility: "Medium",
    description: "One of India's largest private sector banks offering a wide range of financial products."
  },
  {
    symbol: "ITC.NS",
    name: "ITC Ltd",
    sector: "FMCG",
    currentPrice: 430.25,
    historicalReturns: {
      oneYear: 10.2,
      threeYear: 8.7,
      fiveYear: 7.5,
      tenYear: 9.8
    },
    riskLevel: "Conservative",
    volatility: "Low",
    description: "Diversified conglomerate with presence in FMCG, hotels, paperboards, and agriculture."
  },
  {
    symbol: "ASIANPAINT.NS",
    name: "Asian Paints",
    sector: "Consumer Durables",
    currentPrice: 3150.70,
    historicalReturns: {
      oneYear: 8.9,
      threeYear: 12.3,
      fiveYear: 16.7,
      tenYear: 19.2
    },
    riskLevel: "Moderately Conservative",
    volatility: "Low to Medium",
    description: "India's leading paint company with strong presence in decorative and industrial segments."
  },
  {
    symbol: "BHARTIARTL.NS",
    name: "Bharti Airtel",
    sector: "Telecom",
    currentPrice: 850.45,
    historicalReturns: {
      oneYear: 18.7,
      threeYear: 16.2,
      fiveYear: 12.8,
      tenYear: 10.5
    },
    riskLevel: "Moderately Aggressive",
    volatility: "Medium to High",
    description: "One of India's leading telecom providers with operations across Asia and Africa."
  },
  {
    symbol: "ZOMATO.NS",
    name: "Zomato",
    sector: "Technology",
    currentPrice: 175.60,
    historicalReturns: {
      oneYear: 45.2,
      threeYear: 0,
      fiveYear: 0,
      tenYear: 0
    },
    riskLevel: "Aggressive",
    volatility: "Very High",
    description: "Leading food delivery platform in India with expanding quick commerce presence."
  },
  {
    symbol: "NESTLEIND.NS",
    name: "Nestle India",
    sector: "FMCG",
    currentPrice: 22450.30,
    historicalReturns: {
      oneYear: 7.5,
      threeYear: 11.2,
      fiveYear: 14.5,
      tenYear: 16.8
    },
    riskLevel: "Conservative",
    volatility: "Low",
    description: "Leading food and beverage company in India with strong brand portfolio."
  }
];

// Function to get all available stocks
export const getAllStocks = (): StockData[] => {
  return stocksData;
};

// Function to filter stocks based on expected returns
export const getStocksMatchingReturns = (expectedReturn: number): StockData[] => {
  const buffer = 2; // Allow stocks with returns within this buffer of expected return
  
  return stocksData.filter(stock => {
    const avgReturn = (stock.historicalReturns.fiveYear + stock.historicalReturns.tenYear) / 2;
    return Math.abs(avgReturn - expectedReturn) <= buffer;
  });
};

// Function to get recommended stocks based on investment preferences
export const getRecommendedStocks = (preferences: InvestmentPreference): RecommendedStock[] => {
  // First, get stocks that match the expected return
  let matchingStocks = getStocksMatchingReturns(preferences.expectedReturn);
  
  // If we don't have enough matching stocks, get some close alternatives
  if (matchingStocks.length < 5) {
    const buffer = 5; // Increased buffer
    matchingStocks = stocksData.filter(stock => {
      const avgReturn = (stock.historicalReturns.fiveYear + stock.historicalReturns.tenYear) / 2;
      return Math.abs(avgReturn - preferences.expectedReturn) <= buffer;
    });
  }
  
  // Sort by closest match to expected return
  matchingStocks.sort((a, b) => {
    const avgReturnA = (a.historicalReturns.fiveYear + a.historicalReturns.tenYear) / 2;
    const avgReturnB = (b.historicalReturns.fiveYear + b.historicalReturns.tenYear) / 2;
    return Math.abs(avgReturnA - preferences.expectedReturn) - Math.abs(avgReturnB - preferences.expectedReturn);
  });
  
  // Take top stocks (at most 8)
  const topStocks = matchingStocks.slice(0, 8);
  
  // Assign allocation percentages (simple equal weighting for now)
  const allocationPercentage = 100 / topStocks.length;
  
  return topStocks.map(stock => ({
    stock,
    allocationPercentage,
    allocationAmount: (preferences.amount * allocationPercentage) / 100
  }));
};

// Function to run investment simulation
export const runInvestmentSimulation = (
  initialAmount: number, 
  selectedStocks: RecommendedStock[],
  years: number
): InvestmentSimulation[] => {
  const simulation: InvestmentSimulation[] = [];
  let currentValue = initialAmount;
  
  for (let year = 1; year <= years; year++) {
    // Calculate weighted return for the year based on selected stocks
    let yearlyReturn = 0;
    
    selectedStocks.forEach(recommendation => {
      // Use historical returns with some randomization to simulate market variations
      const stock = recommendation.stock;
      
      // Base return on 10-year or 5-year historical return
      let baseReturn = stock.historicalReturns.tenYear;
      if (!baseReturn || baseReturn === 0) {
        baseReturn = stock.historicalReturns.fiveYear;
      }
      
      // Add some randomization (-3% to +3%)
      const randomVariation = (Math.random() * 6) - 3;
      const stockReturn = baseReturn + randomVariation;
      
      // Weight by allocation
      yearlyReturn += stockReturn * (recommendation.allocationPercentage / 100);
    });
    
    // Apply return to current value
    const yearlyGain = currentValue * (yearlyReturn / 100);
    currentValue += yearlyGain;
    
    // Record simulation data
    simulation.push({
      year,
      investmentValue: Math.round(currentValue),
      annualReturn: parseFloat(yearlyReturn.toFixed(2)),
      cumulativeReturn: parseFloat(((currentValue / initialAmount - 1) * 100).toFixed(2))
    });
  }
  
  return simulation;
};

// Function to get risk assessment based on expected returns
export const getReturnRiskAssessment = (expectedReturn: number): string => {
  if (expectedReturn <= 8) {
    return "Conservative - Your expected returns are in the lower range, which typically involves lower risk investments like blue-chip stocks and established companies.";
  } else if (expectedReturn <= 12) {
    return "Moderate - Your expected returns are in the medium range, which typically involves a balanced portfolio of established companies and some growth stocks.";
  } else if (expectedReturn <= 16) {
    return "Moderately Aggressive - Your expected returns are above average, which typically involves more exposure to growth stocks and emerging sectors.";
  } else {
    return "Aggressive - Your expected returns are high, which typically involves higher risk investments like small-cap stocks, emerging sectors, and potentially volatile stocks.";
  }
};
