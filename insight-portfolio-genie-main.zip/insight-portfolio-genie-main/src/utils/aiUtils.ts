
import { ReportData } from "../types";
import { toast } from "sonner";

export const generateAIInsights = async (reportData: ReportData): Promise<string> => {
  // In a real application, this would call an OpenAI API
  // For this MVP, we'll generate simulated AI responses based on the risk profile
  
  const { name, riskProfile, portfolio, investmentGoals } = reportData;
  
  const goalSpecificInsight = investmentGoals 
    ? `\nConsidering your goal to "${investmentGoals}", this portfolio structure is well-positioned to help you achieve this objective while maintaining an appropriate risk level.`
    : "";
  
  const basePrompt = `Based on ${name}'s risk profile (${riskProfile}) and selected portfolio (${portfolio.title}), here's a personalized investment analysis:`;
  
  const insights = {
    "Conservative": `${basePrompt}
    
Your conservative approach indicates you prioritize capital preservation over aggressive growth. The ${portfolio.title} portfolio aligns well with this preference by allocating ${portfolio.allocation.find(a => a.name === "Bonds")?.percentage}% to bonds, providing stability while still offering modest growth potential.

Given current market conditions, this portfolio's ${portfolio.expectedReturn} expected return should help you stay ahead of inflation while minimizing volatility. I recommend quarterly rebalancing to maintain your target allocations.${goalSpecificInsight}

For tax efficiency, consider holding bonds in tax-advantaged accounts and exploring municipal bonds for taxable accounts. As interest rates stabilize, you may want to gradually extend duration on fixed-income holdings.`,

    "Moderately Conservative": `${basePrompt}
    
Your moderately conservative profile balances safety with modest growth objectives. The ${portfolio.title} portfolio's ${portfolio.allocation.find(a => a.name === "Stocks")?.percentage}% stock allocation provides growth potential while the ${portfolio.allocation.find(a => a.name === "Bonds")?.percentage}% bond component offers stability.

This ${portfolio.expectedReturn} expected return range should help you achieve moderate long-term growth while experiencing only limited short-term volatility. Consider semi-annual rebalancing to maintain your target risk level.${goalSpecificInsight}

Given recent market performance, you might benefit from dollar-cost averaging into equity positions rather than investing a lump sum. Consider diversifying your stock exposure across both domestic and international markets for added stability.`,

    "Moderate": `${basePrompt}
    
With your moderate risk profile, you're balancing growth and stability effectively. The ${portfolio.title} portfolio's ${portfolio.allocation.find(a => a.name === "Stocks")?.percentage}% equity allocation provides solid growth potential while the ${portfolio.allocation.find(a => a.name === "Bonds")?.percentage}% fixed-income component helps reduce overall volatility.

This balanced approach targets ${portfolio.expectedReturn} expected returns and should serve you well in various market conditions. Quarterly rebalancing is recommended to maintain your desired risk/reward profile.${goalSpecificInsight}

Consider incorporating both growth and value stocks in your equity allocation, and explore adding factor-based ETFs to potentially enhance returns. For fixed income, a laddered approach with varying maturities may help manage interest rate risk.`,

    "Moderately Aggressive": `${basePrompt}
    
Your moderately aggressive profile indicates comfort with higher volatility in pursuit of stronger returns. The ${portfolio.title} portfolio's ${portfolio.allocation.find(a => a.name === "Stocks")?.percentage}% equity allocation positions you for substantial growth while maintaining some stability with ${portfolio.allocation.find(a => a.name === "Bonds")?.percentage}% in fixed income.

This growth-oriented approach targets ${portfolio.expectedReturn} expected returns and is appropriate for investors with longer time horizons. Consider quarterly rebalancing to maintain target allocations and manage risk.${goalSpecificInsight}

Within your equity allocation, consider overweighting small and mid-cap stocks for enhanced growth potential. International exposure, particularly to emerging markets, could also boost long-term returns. The ${portfolio.allocation.find(a => a.name === "Alternative")?.percentage}% allocation to alternatives provides helpful diversification.`,

    "Aggressive": `${basePrompt}
    
Your aggressive risk profile shows you prioritize maximum growth potential and can tolerate significant market fluctuations. The ${portfolio.title} portfolio's ${portfolio.allocation.find(a => a.name === "Stocks")?.percentage}% equity allocation is designed to maximize long-term capital appreciation.

With expected returns of ${portfolio.expectedReturn}, this portfolio has substantial growth potential but will experience higher volatility. Consider quarterly rebalancing to maintain your target allocations while taking advantage of market movements.${goalSpecificInsight}

Your equity allocation should include growth-oriented sectors and potentially higher allocation to small-cap and emerging market stocks. The minimal fixed income component is primarily for tactical opportunities rather than income generation. Consider maintaining a small cash reserve for opportunistic investments during market corrections.`
  };
  
  return insights[riskProfile] || `${basePrompt}\n\nBased on your risk profile and portfolio selection, I recommend a diversified approach focusing on long-term growth with periodic rebalancing to maintain your target asset allocation.`;
};

export const generatePDF = async (reportData: ReportData): Promise<void> => {
  try {
    // Dynamically import jspdf to avoid server-side rendering issues
    const jsPDF = (await import('jspdf')).default;
    const { default: autoTable } = await import('jspdf-autotable');
    
    const { name, email, riskProfile, portfolio, aiInsights, date } = reportData;
    
    // Create new PDF document
    const doc = new jsPDF();
    
    // Add company logo/header
    doc.setFillColor(10, 36, 99); // finance-blue
    doc.rect(0, 0, 210, 30, 'F');
    
    doc.setFont("helvetica", "bold");
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(22);
    doc.text("AI Financial Portfolio Report", 105, 15, { align: "center" });
    
    // Add client information
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(12);
    doc.text(`Client: ${name}`, 20, 40);
    if (email) doc.text(`Email: ${email}`, 20, 48);
    doc.text(`Risk Profile: ${riskProfile}`, 20, email ? 56 : 48);
    doc.text(`Date: ${date}`, 20, email ? 64 : 56);
    
    // Add portfolio information
    doc.setFontSize(16);
    doc.setFont("helvetica", "bold");
    doc.text("Portfolio Summary", 20, email ? 76 : 68);
    
    doc.setFontSize(12);
    doc.setFont("helvetica", "normal");
    doc.text(`Portfolio Type: ${portfolio.title}`, 20, email ? 86 : 78);
    doc.text(`Expected Return: ${portfolio.expectedReturn}`, 20, email ? 94 : 86);
    doc.text(`Risk Level: ${portfolio.riskLevel}`, 20, email ? 102 : 94);
    doc.text(`Volatility: ${portfolio.volatility}`, 20, email ? 110 : 102);
    
    // Add asset allocation table
    doc.setFontSize(16);
    doc.setFont("helvetica", "bold");
    doc.text("Asset Allocation", 20, email ? 126 : 118);
    
    const tableData = portfolio.allocation.map(asset => [asset.name, `${asset.percentage}%`]);
    
    autoTable(doc, {
      startY: email ? 132 : 124,
      head: [['Asset Class', 'Allocation']],
      body: tableData,
      theme: 'striped',
      headStyles: { fillColor: [30, 132, 127] } // finance-teal
    });
    
    // Add AI insights
    doc.addPage();
    doc.setFontSize(16);
    doc.setFont("helvetica", "bold");
    doc.text("AI-Generated Investment Insights", 20, 20);
    
    doc.setFontSize(11);
    doc.setFont("helvetica", "normal");
    
    const splitInsights = doc.splitTextToSize(aiInsights, 170);
    doc.text(splitInsights, 20, 30);
    
    // Add disclaimer
    doc.setFontSize(8);
    doc.setTextColor(100, 100, 100);
    const pageCount = doc.getNumberOfPages();
    doc.setPage(pageCount);
    const disclaimer = "DISCLAIMER: This report is generated for educational purposes only and does not constitute financial advice. Investment decisions should be made in consultation with a qualified financial advisor.";
    doc.text(disclaimer, 20, doc.internal.pageSize.height - 10);
    
    // Save PDF
    doc.save(`${name.replace(/\s+/g, '_')}_Financial_Report.pdf`);
    
    return Promise.resolve();
  } catch (error) {
    console.error("Error generating PDF:", error);
    toast.error("Failed to generate PDF. Please try again.");
    return Promise.reject(error);
  }
};
