import { RiskProfile, PortfolioRecommendation, UserResponse, HistoricalPerformance } from "@/types";

/**
 * Calculates risk profile score based on user responses
 */
export const calculateRiskScore = (responses: UserResponse[]): number => {
  // Enhanced algorithm: apply different weights to different questions
  const questionWeights = {
    1: 1.5, // Time horizon is important
    2: 2.0, // How they react to market downturns is very important
    3: 1.2, // Investment goal
    4: 0.8, // Investing experience
    5: 1.8, // Risk attitude is important
    6: 0.5, // How often they check performance
    7: 1.2  // Percentage of net worth
  };
  
  let weightedScore = 0;
  let totalWeight = 0;
  
  responses.forEach((response) => {
    const weight = questionWeights[response.questionId as keyof typeof questionWeights] || 1;
    weightedScore += response.value * weight;
    totalWeight += weight * 4; // 4 is max value
  });
  
  return (weightedScore / totalWeight) * 100;
};

/**
 * Maps risk score to risk profile
 */
export const mapScoreToProfile = (score: number): RiskProfile => {
  if (score < 20) return "Conservative";
  if (score < 40) return "Moderately Conservative";
  if (score < 60) return "Moderate";
  if (score < 80) return "Moderately Aggressive";
  return "Aggressive";
};

/**
 * Generate historical performance data based on risk profile
 */
const generateHistoricalPerformance = (riskLevel: RiskProfile): HistoricalPerformance[] => {
  // Base volatility factors for different risk levels
  const volatilityFactors = {
    "Conservative": 0.5,
    "Moderately Conservative": 0.8,
    "Moderate": 1.2,
    "Moderately Aggressive": 1.8,
    "Aggressive": 2.5
  };
  
  // Base returns for different risk levels
  const baseReturns = {
    "Conservative": 4,
    "Moderately Conservative": 5.5,
    "Moderate": 7,
    "Moderately Aggressive": 9,
    "Aggressive": 11
  };
  
  const volatility = volatilityFactors[riskLevel];
  const baseReturn = baseReturns[riskLevel];
  
  // Market conditions by year (simplified for simulation)
  const marketConditions = {
    "2016": 1.2,  // Good year
    "2017": 1.5,  // Very good year
    "2018": 0.6,  // Bad year
    "2019": 1.3,  // Good year
    "2020": 0.4,  // Very bad year (COVID)
    "2021": 1.8,  // Excellent year
    "2022": 0.7,  // Bad year
    "2023": 1.1,  // Above average
    "2024": 1.0,  // Average year
  };
  
  return Object.entries(marketConditions).map(([year, condition]) => {
    // Calculate return with some randomness based on volatility and market condition
    const randomFactor = (Math.random() * 2 - 1) * volatility;
    const returnValue = baseReturn * condition + randomFactor;
    return {
      year,
      return: parseFloat(returnValue.toFixed(1))
    };
  }).sort((a, b) => parseInt(a.year) - parseInt(b.year));
};

/**
 * Get portfolio recommendations based on risk profile
 */
export const getPortfolioRecommendations = (profile: RiskProfile): PortfolioRecommendation[] => {
  switch(profile) {
    case "Conservative":
      return [
        {
          title: "Income Focus",
          description: "A portfolio designed to preserve capital and generate steady income with minimal risk.",
          expectedReturn: "3-5%",
          riskLevel: "Conservative",
          volatility: "Low",
          allocation: [
            { name: "Bonds", percentage: 60, color: "#4C72B0" },
            { name: "Cash", percentage: 15, color: "#8bbe8a" },
            { name: "Stocks", percentage: 20, color: "#C44E52" },
            { name: "Alternative", percentage: 5, color: "#8172B3" }
          ],
          historicalPerformance: generateHistoricalPerformance("Conservative")
        },
        {
          title: "Stability Plus",
          description: "A slightly more aggressive approach while maintaining strong emphasis on stability.",
          expectedReturn: "4-6%",
          riskLevel: "Conservative",
          volatility: "Low to Medium",
          allocation: [
            { name: "Bonds", percentage: 50, color: "#4C72B0" },
            { name: "Cash", percentage: 10, color: "#8bbe8a" },
            { name: "Stocks", percentage: 30, color: "#C44E52" },
            { name: "Alternative", percentage: 10, color: "#8172B3" }
          ],
          historicalPerformance: generateHistoricalPerformance("Conservative")
        }
      ];
    
    case "Moderately Conservative":
      return [
        {
          title: "Income & Growth",
          description: "Balanced approach with emphasis on income generation and some growth potential.",
          expectedReturn: "4-7%",
          riskLevel: "Moderately Conservative",
          volatility: "Low to Medium",
          allocation: [
            { name: "Bonds", percentage: 45, color: "#4C72B0" },
            { name: "Cash", percentage: 10, color: "#8bbe8a" },
            { name: "Stocks", percentage: 35, color: "#C44E52" },
            { name: "Alternative", percentage: 10, color: "#8172B3" }
          ],
          historicalPerformance: generateHistoricalPerformance("Moderately Conservative")
        },
        {
          title: "Conservative Growth",
          description: "Focus on long-term growth while maintaining reasonable stability.",
          expectedReturn: "5-8%",
          riskLevel: "Moderately Conservative", 
          volatility: "Medium",
          allocation: [
            { name: "Bonds", percentage: 40, color: "#4C72B0" },
            { name: "Cash", percentage: 5, color: "#8bbe8a" },
            { name: "Stocks", percentage: 45, color: "#C44E52" },
            { name: "Alternative", percentage: 10, color: "#8172B3" }
          ],
          historicalPerformance: generateHistoricalPerformance("Moderately Conservative")
        }
      ];
      
    case "Moderate":
      return [
        {
          title: "Balanced Growth",
          description: "Equal emphasis on growth and income with moderate risk levels.",
          expectedReturn: "6-8%",
          riskLevel: "Moderate",
          volatility: "Medium",
          allocation: [
            { name: "Bonds", percentage: 35, color: "#4C72B0" },
            { name: "Cash", percentage: 5, color: "#8bbe8a" },
            { name: "Stocks", percentage: 50, color: "#C44E52" },
            { name: "Alternative", percentage: 10, color: "#8172B3" }
          ],
          historicalPerformance: generateHistoricalPerformance("Moderate")
        },
        {
          title: "Global Opportunities",
          description: "Diversified approach across global markets with moderate risk.",
          expectedReturn: "6-9%",
          riskLevel: "Moderate",
          volatility: "Medium",
          allocation: [
            { name: "Bonds", percentage: 30, color: "#4C72B0" },
            { name: "Cash", percentage: 5, color: "#8bbe8a" },
            { name: "Stocks", percentage: 55, color: "#C44E52" },
            { name: "Alternative", percentage: 10, color: "#8172B3" }
          ],
          historicalPerformance: generateHistoricalPerformance("Moderate")
        }
      ];

    case "Moderately Aggressive":
      return [
        {
          title: "Growth Focus",
          description: "Emphasis on long-term capital appreciation with higher risk tolerance.",
          expectedReturn: "7-10%",
          riskLevel: "Moderately Aggressive",
          volatility: "Medium to High",
          allocation: [
            { name: "Bonds", percentage: 20, color: "#4C72B0" },
            { name: "Cash", percentage: 5, color: "#8bbe8a" },
            { name: "Stocks", percentage: 65, color: "#C44E52" },
            { name: "Alternative", percentage: 10, color: "#8172B3" }
          ],
          historicalPerformance: generateHistoricalPerformance("Moderately Aggressive")
        },
        {
          title: "Dynamic Growth",
          description: "Aims for strong growth with calculated risk-taking strategies.",
          expectedReturn: "8-11%",
          riskLevel: "Moderately Aggressive",
          volatility: "High",
          allocation: [
            { name: "Bonds", percentage: 15, color: "#4C72B0" },
            { name: "Cash", percentage: 5, color: "#8bbe8a" },
            { name: "Stocks", percentage: 70, color: "#C44E52" },
            { name: "Alternative", percentage: 10, color: "#8172B3" }
          ],
          historicalPerformance: generateHistoricalPerformance("Moderately Aggressive")
        }
      ];

    case "Aggressive":
      return [
        {
          title: "Maximum Growth",
          description: "Focused on maximizing long-term returns with high risk tolerance.",
          expectedReturn: "9-12%",
          riskLevel: "Aggressive",
          volatility: "High",
          allocation: [
            { name: "Bonds", percentage: 10, color: "#4C72B0" },
            { name: "Cash", percentage: 5, color: "#8bbe8a" },
            { name: "Stocks", percentage: 75, color: "#C44E52" },
            { name: "Alternative", percentage: 10, color: "#8172B3" }
          ],
          historicalPerformance: generateHistoricalPerformance("Aggressive")
        },
        {
          title: "Aggressive Opportunities",
          description: "Seeks maximum capital appreciation with very high risk tolerance.",
          expectedReturn: "10-14%",
          riskLevel: "Aggressive",
          volatility: "Very High",
          allocation: [
            { name: "Bonds", percentage: 5, color: "#4C72B0" },
            { name: "Cash", percentage: 0, color: "#8bbe8a" },
            { name: "Stocks", percentage: 85, color: "#C44E52" },
            { name: "Alternative", percentage: 10, color: "#8172B3" }
          ],
          historicalPerformance: generateHistoricalPerformance("Aggressive")
        }
      ];
      
    default:
      return [];
  }
};

/**
 * Get risk questions for assessment
 */
export const getRiskQuestions = () => {
  return [
    {
      id: 1,
      question: "What is your investment time horizon?",
      options: [
        { value: 0, text: "Less than 1 year" },
        { value: 1, text: "1-3 years" },
        { value: 2, text: "3-5 years" },
        { value: 3, text: "5-10 years" },
        { value: 4, text: "More than 10 years" }
      ]
    },
    {
      id: 2,
      question: "How would you react if your investments declined by 20%?",
      options: [
        { value: 0, text: "Sell everything immediately" },
        { value: 1, text: "Sell a portion to prevent further losses" },
        { value: 2, text: "Do nothing and wait it out" },
        { value: 3, text: "Wait for recovery and then reassess" },
        { value: 4, text: "Buy more at the lower price" }
      ]
    },
    {
      id: 3,
      question: "What is your primary investment goal?",
      options: [
        { value: 0, text: "Preserve my initial investment" },
        { value: 1, text: "Generate stable income" },
        { value: 2, text: "Balance between growth and income" },
        { value: 3, text: "Achieve long-term growth" },
        { value: 4, text: "Maximize growth potential" }
      ]
    },
    {
      id: 4,
      question: "How much investing experience do you have?",
      options: [
        { value: 0, text: "None" },
        { value: 1, text: "Some knowledge but limited experience" },
        { value: 2, text: "Basic understanding with some experience" },
        { value: 3, text: "Good knowledge with moderate experience" },
        { value: 4, text: "Extensive knowledge and experience" }
      ]
    },
    {
      id: 5,
      question: "Which statement best describes your attitude toward investment risk?",
      options: [
        { value: 0, text: "I cannot tolerate any investment losses" },
        { value: 1, text: "I can tolerate small fluctuations in my investments" },
        { value: 2, text: "I can handle moderate fluctuations for better returns" },
        { value: 3, text: "I am comfortable with significant fluctuations for higher returns" },
        { value: 4, text: "I embrace volatility for maximum long-term growth" }
      ]
    },
    {
      id: 6,
      question: "How often would you check the performance of your investments?",
      options: [
        { value: 0, text: "Daily" },
        { value: 1, text: "Weekly" },
        { value: 2, text: "Monthly" },
        { value: 3, text: "Quarterly" },
        { value: 4, text: "Annually or less frequently" }
      ]
    },
    {
      id: 7,
      question: "What percentage of your liquid net worth are you planning to invest?",
      options: [
        { value: 4, text: "Less than 20%" },
        { value: 3, text: "20-40%" },
        { value: 2, text: "40-60%" },
        { value: 1, text: "60-80%" },
        { value: 0, text: "More than 80%" }
      ]
    }
  ];
};
