
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { UserProfile } from "@/types";

interface UserInfoFormProps {
  onComplete: (userProfile: UserProfile) => void;
}

const UserInfoForm = ({ onComplete }: UserInfoFormProps) => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [investmentGoals, setInvestmentGoals] = useState("");
  const [errors, setErrors] = useState<{name?: string; email?: string}>({});

  const validateEmail = (email: string) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simple validation
    const newErrors: {name?: string; email?: string} = {};
    if (!name.trim()) newErrors.name = "Name is required";
    if (!email.trim()) newErrors.email = "Email is required";
    else if (!validateEmail(email)) newErrors.email = "Please enter a valid email address";
    
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    // Clear errors
    setErrors({});
    
    // Submit user profile
    onComplete({ name, email, investmentGoals });
    toast.success("Profile saved! Let's continue to your risk assessment.");
  };

  return (
    <Card className="w-full max-w-3xl mx-auto shadow-lg animate-fade-in portfolio-card">
      <CardHeader>
        <CardTitle className="text-2xl font-bold text-center">Welcome to Your AI Financial Advisor</CardTitle>
        <CardDescription className="text-center">
          Let's personalize your experience! Please share some information about yourself.
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className={errors.name ? "border-red-500" : ""}
              />
              {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
            </div>
            
            <div>
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={errors.email ? "border-red-500" : ""}
              />
              {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
            </div>
            
            <div>
              <Label htmlFor="goals">What are your investment goals? (Optional)</Label>
              <Textarea
                id="goals"
                placeholder="e.g., Retirement in 20 years, saving for a house down payment, college fund..."
                value={investmentGoals}
                onChange={(e) => setInvestmentGoals(e.target.value)}
                className="resize-none h-32"
              />
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" className="w-full bg-finance-blue hover:bg-finance-blue/90">
            Continue to Risk Assessment
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
};

export default UserInfoForm;
