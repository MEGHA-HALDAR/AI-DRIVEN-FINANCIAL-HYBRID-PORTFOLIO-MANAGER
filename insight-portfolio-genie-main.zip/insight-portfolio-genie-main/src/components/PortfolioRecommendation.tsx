
import { useState } from "react";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip, LineChart, Line, XAxis, YAxis, CartesianGrid } from "recharts";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { PortfolioRecommendation as PortfolioRecommendationType } from "@/types";

interface PortfolioRecommendationProps {
  portfolios: PortfolioRecommendationType[];
  onSelectPortfolio: (portfolio: PortfolioRecommendationType) => void;
}

const PortfolioRecommendation = ({ portfolios, onSelectPortfolio }: PortfolioRecommendationProps) => {
  const [selectedPortfolioIndex, setSelectedPortfolioIndex] = useState(0);
  const [activeTab, setActiveTab] = useState<string>("allocation");
  const selectedPortfolio = portfolios[selectedPortfolioIndex];
  
  const handleSelectPortfolio = (index: number) => {
    setSelectedPortfolioIndex(index);
  };
  
  const handleContinue = () => {
    onSelectPortfolio(selectedPortfolio);
  };

  const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent, index }: any) => {
    const RADIAN = Math.PI / 180;
    const radius = innerRadius + (outerRadius - innerRadius) * 0.6;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
      <text x={x} y={y} fill="white" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central">
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };

  return (
    <Card className="w-full max-w-4xl mx-auto shadow-lg animate-fade-in portfolio-card">
      <CardHeader>
        <CardTitle className="text-2xl font-bold text-center">Recommended Portfolios</CardTitle>
        <CardDescription className="text-center">
          Based on your risk profile, we've created tailored portfolio options
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs 
          defaultValue={`portfolio-${selectedPortfolioIndex}`} 
          onValueChange={(value) => handleSelectPortfolio(parseInt(value.split('-')[1]))}
          className="w-full"
        >
          <TabsList className="w-full grid grid-cols-2">
            {portfolios.map((portfolio, index) => (
              <TabsTrigger key={index} value={`portfolio-${index}`}>
                {portfolio.title}
              </TabsTrigger>
            ))}
          </TabsList>
          
          {portfolios.map((portfolio, index) => (
            <TabsContent key={index} value={`portfolio-${index}`} className="pt-4 animate-fade-in">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="flex flex-col">
                  <h3 className="font-semibold text-xl mb-2">{portfolio.title}</h3>
                  <p className="text-muted-foreground mb-4">{portfolio.description}</p>
                  
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="bg-muted rounded-lg p-4">
                      <div className="text-sm text-muted-foreground">Expected Return</div>
                      <div className="font-medium text-lg">{portfolio.expectedReturn}</div>
                    </div>
                    <div className="bg-muted rounded-lg p-4">
                      <div className="text-sm text-muted-foreground">Volatility</div>
                      <div className="font-medium text-lg">{portfolio.volatility}</div>
                    </div>
                  </div>
                  
                  <div className="mt-auto">
                    <h4 className="font-medium mb-2">Risk Level</h4>
                    <Badge 
                      className={`
                        ${portfolio.riskLevel === "Conservative" ? "bg-blue-500" : ""}
                        ${portfolio.riskLevel === "Moderately Conservative" ? "bg-teal-500" : ""}
                        ${portfolio.riskLevel === "Moderate" ? "bg-green-500" : ""}
                        ${portfolio.riskLevel === "Moderately Aggressive" ? "bg-yellow-500" : ""}
                        ${portfolio.riskLevel === "Aggressive" ? "bg-red-500" : ""}
                      `}
                    >
                      {portfolio.riskLevel}
                    </Badge>
                  </div>
                </div>
                
                <div className="chart-container">
                  <Tabs defaultValue="allocation" onValueChange={setActiveTab}>
                    <TabsList className="mb-2">
                      <TabsTrigger value="allocation">Asset Allocation</TabsTrigger>
                      <TabsTrigger value="performance">Performance History</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="allocation" className="h-[250px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={portfolio.allocation}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={renderCustomizedLabel}
                            outerRadius={100}
                            fill="#8884d8"
                            dataKey="percentage"
                          >
                            {portfolio.allocation.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Legend layout="vertical" verticalAlign="middle" align="right" />
                          <Tooltip formatter={(value) => `${value}%`} />
                        </PieChart>
                      </ResponsiveContainer>
                    </TabsContent>
                    
                    <TabsContent value="performance" className="h-[250px]">
                      {portfolio.historicalPerformance ? (
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart
                            data={portfolio.historicalPerformance}
                            margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="year" />
                            <YAxis tickFormatter={(value) => `${value}%`} />
                            <Tooltip formatter={(value) => `${value}%`} />
                            <Line 
                              type="monotone" 
                              dataKey="return" 
                              stroke={
                                portfolio.riskLevel === "Conservative" ? "#3b82f6" :
                                portfolio.riskLevel === "Moderately Conservative" ? "#14b8a6" :
                                portfolio.riskLevel === "Moderate" ? "#22c55e" :
                                portfolio.riskLevel === "Moderately Aggressive" ? "#eab308" :
                                "#ef4444"
                              } 
                              strokeWidth={2} 
                              dot={{ r: 4 }} 
                            />
                          </LineChart>
                        </ResponsiveContainer>
                      ) : (
                        <div className="flex items-center justify-center h-full text-muted-foreground">
                          No historical data available
                        </div>
                      )}
                    </TabsContent>
                  </Tabs>
                </div>
              </div>
              
              <div className="mt-6 pt-4 border-t">
                <h4 className="font-medium mb-2">Portfolio Comparison</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {portfolio.allocation.map((asset, i) => (
                    <div key={i} className="bg-muted rounded-lg p-3 text-center">
                      <div className="text-sm text-muted-foreground">{asset.name}</div>
                      <div className="font-medium">{asset.percentage}%</div>
                      <div 
                        className="w-full h-2 mt-1 rounded-full" 
                        style={{ backgroundColor: asset.color }}
                      ></div>
                    </div>
                  ))}
                </div>
              </div>
              
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-center">
        <Button 
          onClick={handleContinue}
          className="w-full max-w-xs bg-finance-blue hover:bg-finance-blue/90"
        >
          Select This Portfolio
        </Button>
      </CardFooter>
    </Card>
  );
};

export default PortfolioRecommendation;
