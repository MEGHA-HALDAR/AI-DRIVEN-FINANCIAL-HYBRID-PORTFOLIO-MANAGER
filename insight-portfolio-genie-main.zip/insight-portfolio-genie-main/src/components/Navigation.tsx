import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ChartLine, PieChart } from "lucide-react";
const Navigation = () => {
  const location = useLocation();
  return <nav className="bg-white border-b shadow-sm">
      <div className="container flex items-center justify-between h-16 mx-auto px-4">
        <Link to="/" className="font-bold text-xl text-finance-blue flex items-center">
          <PieChart className="h-5 w-5 mr-2" />
          <span>cortexa.finance</span>
        </Link>
        
        <div className="flex space-x-1">
          <Button asChild variant={location.pathname === "/" ? "default" : "ghost"}>
            <Link to="/">Portfolio Manager</Link>
          </Button>
          
          <Button asChild variant={location.pathname === "/indian-stock-market" ? "default" : "ghost"}>
            <Link to="/indian-stock-market" className="flex items-center">
              <ChartLine className="h-4 w-4 mr-2" />
              <span>Indian Stock Market</span>
            </Link>
          </Button>
        </div>
      </div>
    </nav>;
};
export default Navigation;