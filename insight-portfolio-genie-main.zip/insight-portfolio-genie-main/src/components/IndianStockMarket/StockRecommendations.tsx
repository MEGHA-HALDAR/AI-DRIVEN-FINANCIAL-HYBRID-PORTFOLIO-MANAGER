import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { InvestmentPreference, RecommendedStock } from "@/types";
import { TrendingUp, ChartLine, Info, RefreshCw } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { useRealTimeStockData } from "@/hooks/useRealTimeStockData";
import { useToast } from "@/hooks/use-toast";

interface StockRecommendationsProps {
  preferences: InvestmentPreference;
  recommendedStocks: RecommendedStock[];
  onSelectStocks: (selected: RecommendedStock[]) => void;
  onBack: () => void;
}

const StockRecommendations = ({ preferences, recommendedStocks, onSelectStocks, onBack }: StockRecommendationsProps) => {
  const [selectedStocks, setSelectedStocks] = useState<{ [key: string]: boolean }>(
    Object.fromEntries(recommendedStocks.map(stock => [stock.stock.symbol, true]))
  );
  
  const [updatedStocks, setUpdatedStocks] = useState(recommendedStocks);
  const { toast } = useToast();
  
  // Extract symbols for real-time data fetching
  const symbols = recommendedStocks.map(stock => stock.stock.symbol);
  
  const { data: realTimeData, isLoading, error, refetch } = useRealTimeStockData(symbols);
  
  // Update stock prices with real-time data
  useEffect(() => {
    if (realTimeData && realTimeData.length > 0) {
      const updated = recommendedStocks.map(recommendation => {
        const realTimeStock = realTimeData.find((rt: any) => rt.symbol === recommendation.stock.symbol);
        
        if (realTimeStock && realTimeStock.success && realTimeStock.price) {
          return {
            ...recommendation,
            stock: {
              ...recommendation.stock,
              currentPrice: realTimeStock.price
            }
          };
        }
        
        return recommendation;
      });
      
      setUpdatedStocks(updated);
      
      const successCount = realTimeData.filter((rt: any) => rt.success).length;
      if (successCount > 0) {
        toast({
          title: "Stock Prices Updated",
          description: `Successfully updated ${successCount} stock prices with real-time data.`,
        });
      }
    }
  }, [realTimeData, recommendedStocks, toast]);
  
  const handleStockToggle = (symbol: string) => {
    setSelectedStocks(prev => ({
      ...prev,
      [symbol]: !prev[symbol]
    }));
  };
  
  const handleContinue = () => {
    const selected = updatedStocks.filter(stock => selectedStocks[stock.stock.symbol]);
    if (selected.length === 0) {
      return;
    }
    
    const totalPercentage = 100;
    const percentagePerStock = totalPercentage / selected.length;
    const adjustedSelections = selected.map(stock => ({
      ...stock,
      allocationPercentage: percentagePerStock,
      allocationAmount: (preferences.amount * percentagePerStock) / 100
    }));
    
    onSelectStocks(adjustedSelections);
  };
  
  const selectedCount = Object.values(selectedStocks).filter(Boolean).length;
  const isAnySelected = selectedCount > 0;
  
  return (
    <Card className="w-full max-w-5xl mx-auto shadow-lg animate-fade-in">
      <CardHeader>
        <CardTitle className="text-2xl font-bold flex items-center justify-between">
          Recommended Stocks
          <Button
            variant="outline"
            size="sm"
            onClick={() => refetch()}
            disabled={isLoading}
            className="ml-4"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh Prices
          </Button>
        </CardTitle>
        <CardDescription>
          Based on your expected return of {preferences.expectedReturn}% with an investment of ₹{preferences.amount.toLocaleString('en-IN')}
          {isLoading && <span className="ml-2 text-blue-600">Fetching real-time prices...</span>}
          {error && <span className="ml-2 text-red-600">Using cached prices (API limit reached)</span>}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="bg-muted p-4 rounded-lg mb-6">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-finance-blue" />
            <h3 className="font-medium">Select stocks for your portfolio</h3>
          </div>
          <p className="text-muted-foreground text-sm mt-1">
            We've recommended stocks that historically match your expected return of {preferences.expectedReturn}%. 
            Prices are updated with real-time data from Alpha Vantage.
          </p>
        </div>
        
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12">Select</TableHead>
                <TableHead>Stock</TableHead>
                <TableHead>Sector</TableHead>
                <TableHead className="text-right">Price (₹)</TableHead>
                <TableHead className="text-right">5 Yr Return</TableHead>
                <TableHead className="text-right">10 Yr Return</TableHead>
                <TableHead className="text-right">Risk</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {updatedStocks.map((recommendation) => {
                const realTimeStock = realTimeData?.find((rt: any) => rt.symbol === recommendation.stock.symbol);
                const isRealTime = realTimeStock?.success;
                
                return (
                  <TableRow key={recommendation.stock.symbol}>
                    <TableCell>
                      <Checkbox 
                        checked={!!selectedStocks[recommendation.stock.symbol]}
                        onCheckedChange={() => handleStockToggle(recommendation.stock.symbol)}
                      />
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">{recommendation.stock.name}</div>
                      <div className="text-xs text-muted-foreground">{recommendation.stock.symbol}</div>
                    </TableCell>
                    <TableCell>{recommendation.stock.sector}</TableCell>
                    <TableCell className="text-right font-mono">
                      <div className="flex items-center justify-end gap-1">
                        {recommendation.stock.currentPrice.toLocaleString('en-IN', { maximumFractionDigits: 2 })}
                        {isRealTime && (
                          <Tooltip>
                            <TooltipTrigger>
                              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                            </TooltipTrigger>
                            <TooltipContent>Real-time price</TooltipContent>
                          </Tooltip>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right font-mono">
                      <span className={recommendation.stock.historicalReturns.fiveYear >= 12 ? "text-green-600" : "text-amber-600"}>
                        {recommendation.stock.historicalReturns.fiveYear.toFixed(1)}%
                      </span>
                    </TableCell>
                    <TableCell className="text-right font-mono">
                      <span className={recommendation.stock.historicalReturns.tenYear >= 12 ? "text-green-600" : "text-amber-600"}>
                        {recommendation.stock.historicalReturns.tenYear.toFixed(1)}%
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <Badge
                        className={`
                          ${recommendation.stock.riskLevel === "Conservative" ? "bg-blue-500" : ""}
                          ${recommendation.stock.riskLevel === "Moderately Conservative" ? "bg-teal-500" : ""}
                          ${recommendation.stock.riskLevel === "Moderate" ? "bg-green-500" : ""}
                          ${recommendation.stock.riskLevel === "Moderately Aggressive" ? "bg-yellow-500" : ""}
                          ${recommendation.stock.riskLevel === "Aggressive" ? "bg-red-500" : ""}
                        `}
                      >
                        {recommendation.stock.riskLevel}
                      </Badge>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
        
        <div className="mt-6 text-sm text-muted-foreground flex items-center gap-2">
          <Info className="h-4 w-4" />
          <p>
            Real-time prices are fetched from Alpha Vantage. Historical returns are not indicative of future performance. 
            Stock market investments are subject to market risks.
          </p>
        </div>
        
        <div className="mt-6 bg-muted p-4 rounded-lg">
          <div className="font-medium">Portfolio Summary</div>
          <div className="flex justify-between mt-2 text-sm">
            <span>Selected Stocks:</span>
            <span>{selectedCount} of {recommendedStocks.length}</span>
          </div>
          <div className="flex justify-between mt-1 text-sm">
            <span>Allocation per Stock:</span>
            <span>{isAnySelected ? `${(100 / selectedCount).toFixed(1)}%` : "N/A"}</span>
          </div>
          <div className="flex justify-between mt-1 text-sm">
            <span>Amount per Stock:</span>
            <span>
              {isAnySelected 
                ? `₹${((preferences.amount / selectedCount)).toLocaleString('en-IN', { maximumFractionDigits: 0 })}` 
                : "N/A"}
            </span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button 
          variant="outline" 
          onClick={onBack}
        >
          Back
        </Button>
        <Button 
          onClick={handleContinue}
          className="bg-finance-blue hover:bg-finance-blue/90"
          disabled={selectedCount === 0}
        >
          Run Investment Simulation
        </Button>
      </CardFooter>
    </Card>
  );
};

export default StockRecommendations;
