
import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area, 
  BarChart,
  Bar,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as RechartsTooltip, 
  Legend, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell 
} from "recharts";
import { InvestmentPreference, InvestmentSimulation, RecommendedStock } from "@/types";
import { Download, ArrowDown, ArrowUp, ChartLine, PieChart as PieChartIcon, Info } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { toast } from "sonner";

interface SimulationResultsProps {
  preferences: InvestmentPreference;
  selectedStocks: RecommendedStock[];
  simulationData: InvestmentSimulation[];
  onReset: () => void;
}

const SimulationResults = ({ preferences, selectedStocks, simulationData, onReset }: SimulationResultsProps) => {
  const [activeTab, setActiveTab] = useState<string>("growth");
  
  // Calculate final stats
  const initialAmount = preferences.amount;
  const finalAmount = simulationData[simulationData.length - 1]?.investmentValue || initialAmount;
  const totalGrowth = ((finalAmount / initialAmount) - 1) * 100;
  const averageAnnualReturn = (totalGrowth / simulationData.length);
  
  // Calculate best and worst years
  const bestYear = [...simulationData].sort((a, b) => b.annualReturn - a.annualReturn)[0];
  const worstYear = [...simulationData].sort((a, b) => a.annualReturn - b.annualReturn)[0];
  
  const handleDownload = () => {
    // In a real app, this would generate a PDF report
    toast.success("Report download feature coming soon!");
  };
  
  return (
    <Card className="w-full max-w-5xl mx-auto shadow-lg animate-fade-in">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-2xl font-bold">Investment Simulation Results</CardTitle>
            <CardDescription>
              {simulationData.length} year projection based on historical market data
            </CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={handleDownload}>
            <Download className="h-4 w-4 mr-2" />
            Download Report
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Summary cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="text-sm text-muted-foreground">Initial Investment</div>
              <div className="text-2xl font-bold">₹{initialAmount.toLocaleString('en-IN')}</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-sm text-muted-foreground">Final Value</div>
              <div className="text-2xl font-bold text-green-600">₹{finalAmount.toLocaleString('en-IN')}</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-sm text-muted-foreground">Total Growth</div>
              <div className="text-2xl font-bold flex items-center">
                <ArrowUp className="h-5 w-5 text-green-600 mr-1" />
                {totalGrowth.toFixed(1)}%
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-sm text-muted-foreground">Avg. Annual Return</div>
              <div className="text-2xl font-bold">
                {averageAnnualReturn.toFixed(1)}%
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Disclaimer */}
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-sm text-amber-800">
          <div className="flex items-center gap-2 font-medium">
            <Info className="h-4 w-4" />
            Important Disclaimer
          </div>
          <p className="mt-1">
            This simulation is based on historical market data and is for educational purposes only. 
            Actual stock market performance may vary significantly. Past performance is not indicative of future results.
            Always consult with a financial advisor before making investment decisions.
          </p>
        </div>
        
        {/* Charts */}
        <Tabs defaultValue="growth" onValueChange={setActiveTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="growth">Growth Chart</TabsTrigger>
            <TabsTrigger value="returns">Annual Returns</TabsTrigger>
            <TabsTrigger value="allocation">Portfolio Allocation</TabsTrigger>
          </TabsList>
          
          {/* Growth chart */}
          <TabsContent value="growth">
            <div className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={simulationData}
                  margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="year" 
                    label={{ value: 'Year', position: 'insideBottom', offset: -5 }}
                  />
                  <YAxis 
                    tickFormatter={(value) => `₹${(value / 1000).toFixed(0)}K`}
                    label={{ value: 'Investment Value (₹)', angle: -90, position: 'insideLeft' }}
                  />
                  <RechartsTooltip 
                    formatter={(value) => [`₹${value.toLocaleString('en-IN')}`, "Portfolio Value"]}
                    labelFormatter={(label) => `Year ${label}`}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="investmentValue" 
                    stroke="#2563eb" 
                    fill="#3b82f6" 
                    fillOpacity={0.3} 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
          
          {/* Annual returns chart */}
          <TabsContent value="returns">
            <div className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={simulationData}
                  margin={{ top: 10, right: 30, left: 10, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="year" 
                    label={{ value: 'Year', position: 'insideBottom', offset: -5 }}
                  />
                  <YAxis 
                    tickFormatter={(value) => `${value}%`}
                    label={{ value: 'Annual Return (%)', angle: -90, position: 'insideLeft' }}
                  />
                  <RechartsTooltip 
                    formatter={(value) => [`${value}%`, "Annual Return"]}
                    labelFormatter={(label) => `Year ${label}`}
                  />
                  <Bar 
                    dataKey="annualReturn" 
                    fill="#3b82f6"
                    radius={[4, 4, 0, 0]}
                  >
                    {simulationData.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={entry.annualReturn >= 0 ? "#22c55e" : "#ef4444"} 
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
          
          {/* Portfolio allocation */}
          <TabsContent value="allocation">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={selectedStocks}
                      nameKey={(entry) => entry.stock.name}
                      dataKey="allocationPercentage"
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      fill="#8884d8"
                      label={(entry) => `${entry.stock.name.split(' ')[0]}: ${entry.allocationPercentage.toFixed(1)}%`}
                    >
                      {selectedStocks.map((entry, index) => (
                        <Cell 
                          key={`cell-${index}`} 
                          fill={[
                            "#3b82f6", "#22c55e", "#ef4444", "#eab308", 
                            "#8b5cf6", "#ec4899", "#14b8a6", "#f97316"
                          ][index % 8]} 
                        />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </div>
              
              <div>
                <h3 className="font-medium mb-3">Portfolio Composition</h3>
                <div className="space-y-2">
                  {selectedStocks.map((stock, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: [
                            "#3b82f6", "#22c55e", "#ef4444", "#eab308", 
                            "#8b5cf6", "#ec4899", "#14b8a6", "#f97316"
                          ][index % 8] }}
                        ></div>
                        <div>{stock.stock.name}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">₹{stock.allocationAmount.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</div>
                        <div className="text-xs text-muted-foreground">{stock.allocationPercentage.toFixed(1)}%</div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="mt-6">
                  <h3 className="font-medium mb-2">Sector Distribution</h3>
                  {/* Group by sector */}
                  {(() => {
                    const sectors: { [key: string]: number } = {};
                    selectedStocks.forEach(stock => {
                      const { sector } = stock.stock;
                      if (!sectors[sector]) sectors[sector] = 0;
                      sectors[sector] += stock.allocationPercentage;
                    });
                    
                    return Object.entries(sectors).map(([sector, percentage], index) => (
                      <div key={index} className="flex justify-between items-center mb-1">
                        <div>{sector}</div>
                        <div className="font-medium">{percentage.toFixed(1)}%</div>
                      </div>
                    ));
                  })()}
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
        
        {/* Year highlights */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
          <div className="bg-muted rounded-lg p-4">
            <div className="flex items-center gap-2">
              <ArrowUp className="h-4 w-4 text-green-600" />
              <h4 className="font-medium">Best Year Performance</h4>
            </div>
            <div className="mt-2">
              <div className="flex justify-between">
                <span>Year {bestYear?.year}</span>
                <span className="font-medium text-green-600">+{bestYear?.annualReturn.toFixed(1)}%</span>
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                Investment grew from ₹{(finalAmount / (1 + bestYear?.annualReturn / 100)).toLocaleString('en-IN', { maximumFractionDigits: 0 })} to ₹{finalAmount.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
              </div>
            </div>
          </div>
          
          <div className="bg-muted rounded-lg p-4">
            <div className="flex items-center gap-2">
              <ArrowDown className="h-4 w-4 text-red-600" />
              <h4 className="font-medium">Worst Year Performance</h4>
            </div>
            <div className="mt-2">
              <div className="flex justify-between">
                <span>Year {worstYear?.year}</span>
                <span className="font-medium text-red-600">{worstYear?.annualReturn.toFixed(1)}%</span>
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                Market conditions caused fluctuation in your portfolio value
              </div>
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button 
          variant="outline" 
          onClick={onReset}
        >
          Start New Simulation
        </Button>
      </CardFooter>
    </Card>
  );
};

export default SimulationResults;
