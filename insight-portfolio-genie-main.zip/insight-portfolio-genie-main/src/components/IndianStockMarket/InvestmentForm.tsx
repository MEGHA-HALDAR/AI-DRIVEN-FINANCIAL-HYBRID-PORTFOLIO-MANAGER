
import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { InvestmentPreference } from "@/types";
import { getReturnRiskAssessment } from "@/utils/stockMarketUtils";
import { IndianRupee, Info } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

interface InvestmentFormProps {
  onComplete: (preferences: InvestmentPreference) => void;
}

const InvestmentForm = ({ onComplete }: InvestmentFormProps) => {
  const [amount, setAmount] = useState<number>(10000);
  const [expectedReturn, setExpectedReturn] = useState<number>(12);
  const [investmentHorizon, setInvestmentHorizon] = useState<number>(20);
  const [amountError, setAmountError] = useState<string>("");
  
  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (isNaN(value)) {
      setAmount(0);
      setAmountError("Please enter a valid amount");
      return;
    }
    
    if (value < 1000 || value > 1000000) {
      setAmountError("Amount must be between ₹1,000 and ₹10,00,000");
    } else {
      setAmountError("");
    }
    
    setAmount(value);
  };
  
  const handleSubmit = () => {
    if (amount < 1000 || amount > 1000000) {
      setAmountError("Amount must be between ₹1,000 and ₹10,00,000");
      return;
    }
    
    onComplete({
      amount,
      expectedReturn,
      investmentHorizon
    });
  };
  
  const riskAssessment = getReturnRiskAssessment(expectedReturn);
  
  return (
    <Card className="w-full max-w-4xl mx-auto shadow-lg animate-fade-in">
      <CardHeader>
        <CardTitle className="text-2xl font-bold">Indian Stock Market Investment</CardTitle>
        <CardDescription>
          Let's analyze the Indian stock market based on your investment preferences
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <div className="flex items-center justify-between mb-2">
            <label htmlFor="amount" className="font-medium">
              Investment Amount (₹)
            </label>
            <div className="text-sm text-muted-foreground">Range: ₹1,000 - ₹10,00,000</div>
          </div>
          <div className="flex">
            <div className="relative flex-1">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <IndianRupee className="h-4 w-4 text-muted-foreground" />
              </div>
              <Input
                id="amount"
                type="number"
                value={amount}
                onChange={handleAmountChange}
                className="pl-10"
                min={1000}
                max={1000000}
              />
            </div>
          </div>
          {amountError && <p className="text-sm text-destructive mt-1">{amountError}</p>}
        </div>
        
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <label htmlFor="expectedReturn" className="font-medium">
                Expected Annual Return (%)
              </label>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className="h-4 w-4 text-muted-foreground cursor-help" />
                </TooltipTrigger>
                <TooltipContent side="right">
                  <p className="max-w-xs">
                    Higher expected returns typically come with higher risk. 
                    The Indian stock market has historically delivered ~15% annual returns over long periods.
                  </p>
                </TooltipContent>
              </Tooltip>
            </div>
            <span className="font-medium">{expectedReturn}%</span>
          </div>
          <Slider
            id="expectedReturn"
            value={[expectedReturn]}
            onValueChange={(value) => setExpectedReturn(value[0])}
            min={5}
            max={20}
            step={0.5}
            className="py-4"
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Conservative (5%)</span>
            <span>Balanced (12%)</span>
            <span>Aggressive (20%)</span>
          </div>
        </div>
        
        <div className="bg-muted p-4 rounded-lg mt-6">
          <div className="font-medium mb-1">Risk Assessment</div>
          <p className="text-muted-foreground text-sm">{riskAssessment}</p>
        </div>
        
        <div>
          <div className="flex items-center justify-between mb-2">
            <label htmlFor="investmentHorizon" className="font-medium">
              Simulation Years
            </label>
            <span className="font-medium">{investmentHorizon} years</span>
          </div>
          <Slider
            id="investmentHorizon"
            value={[investmentHorizon]}
            onValueChange={(value) => setInvestmentHorizon(value[0])}
            min={5}
            max={20}
            step={1}
            className="py-4"
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>5 years</span>
            <span>10 years</span>
            <span>15 years</span>
            <span>20 years</span>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button 
          onClick={handleSubmit} 
          className="w-full bg-finance-blue hover:bg-finance-blue/90"
          disabled={!!amountError || amount < 1000}
        >
          Analyze Stock Market Options
        </Button>
      </CardFooter>
    </Card>
  );
};

export default InvestmentForm;
