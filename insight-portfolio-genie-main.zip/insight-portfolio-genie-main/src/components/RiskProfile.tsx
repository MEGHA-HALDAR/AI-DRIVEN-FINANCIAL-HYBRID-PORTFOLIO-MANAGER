
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { RiskProfile as RiskProfileType } from "@/types";

interface RiskProfileProps {
  score: number;
  profile: RiskProfileType;
  onContinue: () => void;
}

const RiskProfile = ({ score, profile, onContinue }: RiskProfileProps) => {
  const getScoreColor = () => {
    if (score < 20) return "bg-blue-500";
    if (score < 40) return "bg-teal-500";
    if (score < 60) return "bg-green-500";
    if (score < 80) return "bg-yellow-500";
    return "bg-red-500";
  };
  
  const profileDescriptions = {
    "Conservative": "You prioritize protecting your investments over growth potential. You prefer stability and are uncomfortable with significant fluctuations in your portfolio value.",
    "Moderately Conservative": "You seek stability with modest growth. You can tolerate some market fluctuations but prefer a smoother investment journey.",
    "Moderate": "You balance growth and stability. You understand that achieving higher returns requires accepting some volatility.",
    "Moderately Aggressive": "You prioritize growth and can accept significant fluctuations to achieve higher long-term returns.",
    "Aggressive": "You focus on maximizing long-term growth potential. You're comfortable with substantial volatility and market downturns."
  };
  
  const profileAttributes = {
    "Conservative": [
      "Capital preservation is primary goal",
      "Lower return potential with minimal volatility",
      "Short to medium investment timeframe",
      "Focus on stable income generation",
      "Minimal exposure to market fluctuations"
    ],
    "Moderately Conservative": [
      "Focus on preserving capital with some growth",
      "Below-average volatility tolerance",
      "Medium-term investment timeframe",
      "Balanced income and growth approach",
      "Limited exposure to market fluctuations"
    ],
    "Moderate": [
      "Balance between growth and stability",
      "Average volatility tolerance",
      "Medium to long-term investment timeframe",
      "Comfortable with market cycles",
      "Diversified approach to investing"
    ],
    "Moderately Aggressive": [
      "Growth is primary goal with some stability",
      "Above-average volatility tolerance",
      "Long-term investment timeframe",
      "Comfort with extended market downturns",
      "Higher exposure to equity markets"
    ],
    "Aggressive": [
      "Maximum growth potential is primary goal",
      "High volatility tolerance",
      "Very long-term investment timeframe",
      "Comfortable with significant market swings",
      "Heavily weighted toward equities and growth assets"
    ]
  };

  return (
    <Card className="w-full max-w-2xl mx-auto shadow-lg animate-fade-in portfolio-card">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl font-bold">Your Risk Profile</CardTitle>
        <CardDescription>
          Based on your answers, we've calculated your investor profile
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="text-center">
          <div className="inline-flex items-center justify-center p-1 rounded-full bg-muted mb-2">
            <div className={`text-white text-sm font-medium h-10 w-10 rounded-full flex items-center justify-center ${getScoreColor()}`}>
              {Math.round(score)}%
            </div>
          </div>
          <h3 className="text-2xl font-bold">{profile}</h3>
          <p className="text-muted-foreground mt-2 max-w-md mx-auto">
            {profileDescriptions[profile]}
          </p>
        </div>
        
        <div className="pt-2">
          <div className="flex justify-between text-xs mb-2">
            <span>Conservative</span>
            <span>Aggressive</span>
          </div>
          <div className="h-3 rounded-full bg-muted relative">
            <div 
              className={`h-3 rounded-full ${getScoreColor()}`}
              style={{ width: `${score}%` }}
            ></div>
            <div 
              className="absolute w-4 h-4 rounded-full bg-white border-2 border-primary top-1/2 transform -translate-y-1/2"
              style={{ left: `calc(${score}% - 8px)` }}
            ></div>
          </div>
        </div>
        
        <div className="bg-muted p-4 rounded-lg mt-4">
          <h4 className="font-medium mb-2">Key Characteristics:</h4>
          <ul className="space-y-1">
            {profileAttributes[profile].map((attribute, index) => (
              <li key={index} className="flex items-start">
                <span className="text-finance-teal mr-2">•</span>
                <span>{attribute}</span>
              </li>
            ))}
          </ul>
        </div>
      </CardContent>
      <CardFooter className="flex justify-center">
        <Button 
          onClick={onContinue}
          className="w-full max-w-xs bg-finance-blue hover:bg-finance-blue/90"
        >
          View Portfolio Recommendations
        </Button>
      </CardFooter>
    </Card>
  );
};

export default RiskProfile;
