
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Progress } from "@/components/ui/progress";
import { getRiskQuestions } from "@/utils/portfolioUtils";
import { UserResponse, RiskQuestion } from "@/types";
import { ChevronRight, ChevronLeft } from "lucide-react";

interface RiskAssessmentProps {
  onComplete: (responses: UserResponse[]) => void;
}

const RiskAssessment = ({ onComplete }: RiskAssessmentProps) => {
  const questions = getRiskQuestions();
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [responses, setResponses] = useState<UserResponse[]>([]);
  const [currentResponse, setCurrentResponse] = useState<number | null>(null);

  const currentQuestion: RiskQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;

  const handleNext = () => {
    if (currentResponse === null) return;

    const newResponses = [...responses];
    const existingIndex = newResponses.findIndex(r => r.questionId === currentQuestion.id);
    
    if (existingIndex >= 0) {
      newResponses[existingIndex].value = currentResponse;
    } else {
      newResponses.push({
        questionId: currentQuestion.id,
        value: currentResponse
      });
    }
    
    setResponses(newResponses);
    
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      
      const nextQuestionResponse = newResponses.find(r => r.questionId === questions[currentQuestionIndex + 1].id);
      setCurrentResponse(nextQuestionResponse ? nextQuestionResponse.value : null);
    } else {
      onComplete(newResponses);
    }
  };

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
      
      const prevQuestionResponse = responses.find(r => r.questionId === questions[currentQuestionIndex - 1].id);
      setCurrentResponse(prevQuestionResponse ? prevQuestionResponse.value : null);
    }
  };

  const handleOptionSelect = (value: string) => {
    setCurrentResponse(parseInt(value));
  };

  return (
    <Card className="w-full max-w-3xl mx-auto shadow-lg portfolio-card">
      <CardHeader className="pb-2">
        <CardTitle className="text-xl font-medium">Risk Assessment Questionnaire</CardTitle>
        <div className="text-sm text-muted-foreground">
          Question {currentQuestionIndex + 1} of {questions.length}
        </div>
        <Progress value={progress} className="h-1 mt-2" />
      </CardHeader>
      <CardContent className="pt-6 pb-6">
        <h2 className="text-lg font-medium mb-4">{currentQuestion.question}</h2>
        
        <RadioGroup 
          value={currentResponse?.toString() || ""} 
          onValueChange={handleOptionSelect} 
          className="space-y-3"
        >
          {currentQuestion.options.map((option, index) => (
            <div key={index} className="flex items-center space-x-2 p-3 rounded-md hover:bg-muted transition-colors">
              <RadioGroupItem value={option.value.toString()} id={`option-${index}`} />
              <Label htmlFor={`option-${index}`} className="flex-grow cursor-pointer">
                {option.text}
              </Label>
            </div>
          ))}
        </RadioGroup>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button 
          onClick={handlePrevious} 
          disabled={currentQuestionIndex === 0}
          variant="outline"
        >
          <ChevronLeft className="mr-1 h-4 w-4" /> Previous
        </Button>
        
        <Button 
          onClick={handleNext} 
          disabled={currentResponse === null}
          className="bg-finance-blue hover:bg-finance-blue/90"
        >
          {currentQuestionIndex === questions.length - 1 ? "Complete" : "Next"}
          {currentQuestionIndex !== questions.length - 1 && <ChevronRight className="ml-1 h-4 w-4" />}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default RiskAssessment;
