
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from "recharts";
import { Download, MessageSquare } from "lucide-react";
import { ReportData } from "@/types";
import { generateAIInsights, generatePDF } from "@/utils/aiUtils";
import { toast } from "sonner";

interface ReportGenerationProps {
  reportData: ReportData;
  onReset: () => void;
}

const ReportGeneration = ({ reportData, onReset }: ReportGenerationProps) => {
  const [insights, setInsights] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(true);
  const [generating, setGenerating] = useState<boolean>(false);
  const [showChat, setShowChat] = useState<boolean>(false);
  const [question, setQuestion] = useState<string>("");
  const [chatHistory, setChatHistory] = useState<{role: string; content: string}[]>([]);
  
  useEffect(() => {
    const loadInsights = async () => {
      try {
        const aiInsights = await generateAIInsights(reportData);
        // Simulate API delay
        setTimeout(() => {
          setInsights(aiInsights);
          setLoading(false);
        }, 1500);
      } catch (error) {
        console.error("Error generating insights:", error);
        setLoading(false);
        toast.error("Failed to generate AI insights. Please try again.");
      }
    };
    
    loadInsights();
  }, [reportData]);
  
  const handleDownload = async () => {
    try {
      setGenerating(true);
      const finalReportData = {
        ...reportData,
        aiInsights: insights
      };
      await generatePDF(finalReportData);
      toast.success("Report downloaded successfully!");
      setGenerating(false);
    } catch (error) {
      console.error("Error generating PDF:", error);
      setGenerating(false);
      toast.error("Failed to generate PDF. Please try again.");
    }
  };

  const handleSendQuestion = () => {
    if (!question.trim()) return;
    
    const newMessage = { role: "user", content: question };
    setChatHistory([...chatHistory, newMessage]);
    
    // Simulate AI response
    setTimeout(() => {
      const aiResponse = { 
        role: "assistant", 
        content: "Based on your portfolio selection and risk profile, I would recommend reviewing your asset allocation quarterly. This helps ensure your investments stay aligned with your goals as market conditions change."
      };
      setChatHistory(prev => [...prev, aiResponse]);
    }, 1000);
    
    setQuestion("");
  };

  return (
    <Card className="w-full max-w-4xl mx-auto shadow-lg animate-fade-in portfolio-card">
      <CardHeader className="pb-2">
        <CardTitle className="text-2xl font-bold text-center">Your Investment Report</CardTitle>
        <CardDescription className="text-center">
          AI-generated insights based on your risk profile and selected portfolio
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h2 className="text-xl font-semibold mb-4">Portfolio Summary</h2>
            <div className="space-y-4">
              <div className="bg-muted rounded-lg p-4">
                <div className="text-sm text-muted-foreground">Selected Portfolio</div>
                <div className="font-medium text-lg">{reportData.portfolio.title}</div>
              </div>
              <div className="bg-muted rounded-lg p-4">
                <div className="text-sm text-muted-foreground">Risk Profile</div>
                <div className="font-medium text-lg">{reportData.riskProfile}</div>
              </div>
              <div className="bg-muted rounded-lg p-4">
                <div className="text-sm text-muted-foreground">Expected Annual Return</div>
                <div className="font-medium text-lg">{reportData.portfolio.expectedReturn}</div>
              </div>
              {reportData.investmentGoals && (
                <div className="bg-muted rounded-lg p-4">
                  <div className="text-sm text-muted-foreground">Investment Goals</div>
                  <div className="font-medium">{reportData.investmentGoals}</div>
                </div>
              )}
            </div>
          </div>
          
          <div className="chart-container">
            <h3 className="font-semibold text-center mb-2">Asset Allocation</h3>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={reportData.portfolio.allocation}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="percentage"
                  label={({ name, percentage }) => `${name}: ${percentage}%`}
                  labelLine={true}
                >
                  {reportData.portfolio.allocation.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Legend layout="horizontal" verticalAlign="bottom" align="center" />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
        
        <Separator />
        
        <div>
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            AI-Generated Insights
            {loading && <div className="ml-2 text-xs text-muted-foreground">(Generating...)</div>}
          </h2>
          
          {loading ? (
            <div className="space-y-2">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-[95%]" />
              <Skeleton className="h-4 w-[98%]" />
              <Skeleton className="h-4 w-[75%]" />
              <Skeleton className="h-4 w-[80%]" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-[90%]" />
            </div>
          ) : (
            <ScrollArea className="h-64 rounded-md border p-4">
              {insights.split('\n').map((paragraph, idx) => (
                <p key={idx} className={`mb-3 ${idx === 0 ? 'font-medium' : ''}`}>
                  {paragraph}
                </p>
              ))}
            </ScrollArea>
          )}
        </div>

        {showChat && (
          <div className="border rounded-lg">
            <div className="p-3 border-b bg-muted">
              <h3 className="font-medium">Ask about your portfolio</h3>
            </div>
            <ScrollArea className="h-64 p-4">
              {chatHistory.map((msg, idx) => (
                <div 
                  key={idx} 
                  className={`mb-3 ${msg.role === 'user' ? 'text-right' : ''}`}
                >
                  <div 
                    className={`inline-block px-4 py-2 rounded-lg max-w-[80%] ${
                      msg.role === 'user' 
                        ? 'bg-finance-blue text-white rounded-tr-none'
                        : 'bg-muted rounded-tl-none'
                    }`}
                  >
                    {msg.content}
                  </div>
                </div>
              ))}
              {chatHistory.length === 0 && (
                <div className="text-center text-muted-foreground pt-6">
                  Ask a question about your investment portfolio
                </div>
              )}
            </ScrollArea>
            <div className="p-3 border-t flex gap-2">
              <input
                type="text"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                placeholder="e.g., How often should I rebalance?"
                onKeyDown={(e) => e.key === 'Enter' && handleSendQuestion()}
              />
              <Button onClick={handleSendQuestion}>Send</Button>
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex flex-col sm:flex-row justify-center items-center space-y-2 sm:space-y-0 sm:space-x-4">
        <Button 
          onClick={onReset}
          variant="outline"
          className="w-full sm:w-auto"
        >
          Start Over
        </Button>
        <Button
          onClick={() => setShowChat(!showChat)}
          variant={showChat ? "default" : "outline"}
          className="w-full sm:w-auto"
        >
          <MessageSquare className="mr-2 h-4 w-4" />
          {showChat ? "Hide Chat" : "Chat with AI"}
        </Button>
        <Button 
          onClick={handleDownload}
          className="w-full sm:w-auto bg-finance-blue hover:bg-finance-blue/90"
          disabled={loading || generating}
        >
          <Download className="mr-2 h-4 w-4" />
          {generating ? "Generating..." : "Download Report"}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ReportGeneration;
